package com.yaya.yaya.wallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YayaWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(YayaWalletApplication.class, args);
	}

}
